$.getJSON("https://wger.de/api/v2/exercise/?format=json&Authorization_Token=624a61d08a2a02fa9d4b3cc6f6e3a76b09ef16b9", 
	function(data) {
	console.log(data); 
		/*optional stuff to do after success */ 
	//array 0
	var desc = data.results[0].description;
	var date = data.results[0].creation_date;
	var license_author = data.results[0].license_author;
	//array 1
	var desc1 = data.results[1].description;
	var date1 = data.results[1].creation_date;
	var license_author1 = data.results[1].license_author;
	//array 0
	$('.desc').append(desc);
	$('.date').append(date);
	$('.license_author').append(license_author);
	//array 1
	$('.desc1').append(desc1);
	$('.date1').append(date1);
	$('.license_author1').append(license_author1);

});

$.getJSON("https://wger.de/api/v2/exerciseimage/?format=json&Authorization_Token=624a61d08a2a02fa9d4b3cc6f6e3a76b09ef16b9", 
	function(data) {
	console.log(data);

	var icon = "https://wger.de/media/exercise-images/26/Biceps-curl-1.png";
	console.log(icon);
	$(".icon").attr("src", icon);

});


$.getJSON("https://wger.de/api/v2/exerciseinfo/?format=json&Authorization_Token=624a61d08a2a02fa9d4b3cc6f6e3a76b09ef16b9", 
	function(data) {
	console.log(data); 

	var exerciseName = data.results[0].category.name;
	$('.exerciseName').append(exerciseName);

	var exerciseName1 = data.results[1].category.name;
	$('.exerciseName1').append(exerciseName1);
	});
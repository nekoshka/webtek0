/*

Barbell Equipment

*/

var button = document.getElementById('ExerExerGettext');
var input = document.getElementById('ExerfindThis');
var parentUl = document.getElementById('Exerlist');
input.addEventListener("keyup", function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        document.getElementById('ExerGettext').click();
    }
});

function ExerGettext() {
    fetch('https://wger.de/api/v2/exercise/?language=2&equipment=1&name='+input.value+'&Authorization_Token=624a61d08a2a02fa9d4b3cc6f6e3a76b09ef16b9')
    .then((res) => res.json())
    .then((data) => {
        try {
            try {
                removeElem();
                getValue('description: ' + data.results[0].description);
                getValue('name: ' + data.results[0].name);
                getValue('licensee_author: ' + data.results[0].license_author);

    
            }catch {
                
                getValue('description: ' + data.results[0].description);
                getValue('name: ' + data.results[0].name);
                getValue('licensee_author: ' + data.results[0].license_author);
                
            }
        } catch {
                getValue("What is That Exercise?")
        }
    });
}
function getValue(type) {
    var li = document.createElement('li');
    var value = document.createTextNode(type);
    li.appendChild(value);
    parentUl.appendChild(li);
}

function removeElem() {
    for(var i = 0 ; i <= 5 ; i++) {
        parentUl.removeChild(parentUl.firstChild);
    }
}

<?php
	session_start();
	require_once "googleapi/vendor/autoload.php";
	$gClient = new Google_Client();
	$gClient->setClientId("26941335921-4so2vev4iuo40tkeegg2lcqm2jfg65a0.apps.googleusercontent.com");
	$gClient->setClientSecret("OxaP1Ew883I3Jm8lfY9Zcvwa");
	$gClient->setApplicationName("Webteklogin");
	$gClient->setRedirectUri("http://localhost/login/g-callback.php");
	$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");	
	$con = new mysqli('localhost', 'root','' ,'loginacc');
    if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}	
?>
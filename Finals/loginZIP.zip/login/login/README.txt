Add the cacert.pem in the "C:\wamp64\bin\php\php7.2.4\extras\ssl" in wamp directory
Edit the php.ini file add the following "curl.cainfo="/path/to/downloaded/cacert.pem""

IF theres a problem in the Guzzle "something" then go to the error where the path is 
given by the browser then change:

this

$conf[CURLOPT_SSL_VERIFYHOST] = 2;
$conf[CURLOPT_SSL_VERIFYPEER] = true;

to

$conf[CURLOPT_SSL_VERIFYHOST] = 2;
$conf[CURLOPT_SSL_VERIFYPEER] = FALSE;
